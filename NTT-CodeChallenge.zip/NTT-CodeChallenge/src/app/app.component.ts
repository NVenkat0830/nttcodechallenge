import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  
  enrolleesData: any = [
    {id:"UID00001", name:"Bob Robert2", status:true, dob:"03/12/1979"},
    {id:"UID00002", name:"Robyn Thibod", status:false, dob:"05/20/1984"},
    {id:"UID00003", name:"Jith Banaphar", status:true, dob:"07/24/1982"},
    {id:"UID00004", name:"murthy Venkat", status:false, dob:"05/20/1986"},
    {id:"UID00005", name:"Heinrich Traut", status:true, dob:"12/24/1987"}
  ]

  title = 'NTT Code Challenge';
  edit: any = {};  

  constructor(){
    this.enrolleesData.forEach((el, i) => {
      this.edit[i] = false;      
    });    
  }
  getCurrentEnroll(event, data, i){
    this.edit[i] = true;    
  }

  saveCurrentEnroll(event, data, i){
    this.edit[i] = false;
  }


}
